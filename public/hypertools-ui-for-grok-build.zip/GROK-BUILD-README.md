﻿# HyperTools UI pack for Grok Build

Edit UI here, then send changed files back to Jake to merge and deploy to https://hypertools.app

## Main UI files
- index.html — page structure
- style.css — Deep Teal and Sapphire theme
- ticket-ui.js, trade.js, connect-modal.js, nav-connect.js, dashboard.js
- balances.js, fills.js, open-orders.js, outcomes.js, twap-hist.js
- hl-trade.js, order-build.js — order logic (edit carefully)

## Theme tokens
--bg-main #080D1A, --bg-surface #0F172A, --bg-input #1E293B
--accent-primary #06B6D4, --accent-success #10B981, --accent-danger #F43F5E
--text-primary #F8FAFC, --border-color #334155

Do not return node_modules, dist, or .git.
