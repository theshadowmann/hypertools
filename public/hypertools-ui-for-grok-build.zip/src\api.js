import { HL_INFO, HL_EXCHANGE, HL_WS } from "./hosts.js";
import { mergeMarkets, parsePerpMarkets, parseSpotMarkets } from "./markets.js";
import { enrichOutcomeMarkets, fetchSpotAssetCtxs } from "./outcome-ctxs.js";
import { parseOutcomeMarkets } from "./outcomes.js";
export { HL_INFO, HL_EXCHANGE, HL_WS };
export const DUST = 1e-8;
export const ADDR_RE = /^0x[a-fA-F0-9]{40}$/;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Two-lane Info queue: critical (balances/clearinghouse) always drains before
 * bulk (markets/candles/history). Global max 2 in-flight. Bulk lane can be
 * paused without freezing balances. 429 backoff releases the slot.
 */
const INFO_MAX_INFLIGHT = 2;
let infoInflight = 0;
const criticalWaiters = [];
const bulkWaiters = [];
let bulkPaused = false;

/** Pause only the bulk lane — never blocks clearinghouse / balance fetches. */
export function pauseHlInfo(ms = 8000) {
  bulkPaused = true;
  clearTimeout(pauseHlInfo._t);
  pauseHlInfo._t = setTimeout(() => {
    bulkPaused = false;
    pumpInfoQueue();
  }, ms);
}

function pumpInfoQueue() {
  while (infoInflight < INFO_MAX_INFLIGHT && criticalWaiters.length) {
    const next = criticalWaiters.shift();
    infoInflight += 1;
    next();
  }
  while (!bulkPaused && infoInflight < INFO_MAX_INFLIGHT && bulkWaiters.length) {
    const next = bulkWaiters.shift();
    infoInflight += 1;
    next();
  }
}

function withInfoSlot(priority, fn) {
  const critical = priority === "critical";
  return new Promise((resolve, reject) => {
    const start = () => {
      if (!critical && bulkPaused) {
        infoInflight -= 1;
        bulkWaiters.unshift(start);
        return;
      }
      Promise.resolve()
        .then(fn)
        .then(resolve, reject)
        .finally(() => {
          infoInflight -= 1;
          pumpInfoQueue();
        });
    };
    if (critical) criticalWaiters.push(start);
    else bulkWaiters.push(start);
    pumpInfoQueue();
  });
}

function criticalBackoffMs(attempt) {
  return [400, 800, 1600, 1600][attempt] || 1600;
}

function bulkBackoffMs(attempt) {
  return 1200 * (attempt + 1);
}

async function fetchInfoRaw(body) {
  return fetch(HL_INFO, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

/**
 * Queued Info POST. opts.priority: "critical" | "bulk" (default).
 * Slot is released during 429 backoff so balances are not stuck behind retries.
 */
export function hlInfo(body, opts = {}) {
  const priority = opts.priority === "critical" ? "critical" : "bulk";
  const maxTries = priority === "critical" ? 4 : 6;

  async function attempt(n) {
    const res = await withInfoSlot(priority, () => fetchInfoRaw(body));
    if (res.status === 429 && n < maxTries - 1) {
      const delay = priority === "critical" ? criticalBackoffMs(n) : bulkBackoffMs(n);
      await sleep(delay);
      return attempt(n + 1);
    }
    if (!res.ok) {
      throw new Error("HTTP " + res.status + " from Hyperliquid Info API");
    }
    return res.json();
  }
  return attempt(0);
}

export function hlInfoCritical(body) {
  return hlInfo(body, { priority: "critical" });
}

function settledValue(result, label, errors) {
  if (result.status === "fulfilled") return result.value;
  const msg = (result.reason && result.reason.message) || String(result.reason);
  errors.push(label + ": " + msg);
  return null;
}

function emptyAccountShell() {
  return {
    perps: null,
    spot: null,
    staking: null,
    delegations: null,
    mids: {},
    validatorNames: {},
    openOrders: [],
    fills: [],
    portfolio: null,
    userFees: null,
    userVaultEquities: [],
    leadingVaults: [],
    subAccounts: [],
    abstraction: null,
  };
}

/**
 * Fast path: only what Available to Trade / Balances / Positions need.
 * Paint as soon as this returns — do not wait for orders/fills/portfolio.
 */
export async function loadAccountCore(address) {
  const errors = [];
  let bal = await Promise.allSettled([
    hlInfo({ type: "clearinghouseState", user: address }, { priority: "critical" }),
    hlInfo({ type: "spotClearinghouseState", user: address }, { priority: "critical" }),
    hlInfo({ type: "userAbstraction", user: address }, { priority: "critical" }),
  ]);
  let perps = settledValue(bal[0], "clearinghouseState", errors);
  let spot = settledValue(bal[1], "spotClearinghouseState", errors);
  let abstraction = bal[2].status === "fulfilled" ? bal[2].value : null;

  if ((!perps || !spot) && errors.some((e) => /429|Too Many|HTTP 429/i.test(e))) {
    await sleep(500);
    for (let i = errors.length - 1; i >= 0; i--) {
      if (/clearinghouseState|spotClearinghouseState/i.test(errors[i]) && /429|Too Many|HTTP 429/i.test(errors[i])) {
        errors.splice(i, 1);
      }
    }
    bal = await Promise.allSettled([
      hlInfo({ type: "clearinghouseState", user: address }, { priority: "critical" }),
      hlInfo({ type: "spotClearinghouseState", user: address }, { priority: "critical" }),
      abstraction == null
        ? hlInfo({ type: "userAbstraction", user: address }, { priority: "critical" })
        : Promise.resolve(abstraction),
    ]);
    perps = settledValue(bal[0], "clearinghouseState", errors) || perps;
    spot = settledValue(bal[1], "spotClearinghouseState", errors) || spot;
    if (bal[2].status === "fulfilled") abstraction = bal[2].value;
  }

  return {
    data: {
      ...emptyAccountShell(),
      perps,
      spot,
      abstraction,
    },
    errors,
  };
}

/** Open orders, fills, mids — after core has painted. */
export async function loadAccountBook(address) {
  const errors = [];
  const book = await Promise.allSettled([
    hlInfo({ type: "frontendOpenOrders", user: address }),
    hlInfo({ type: "userFills", user: address }),
    hlInfo({ type: "allMids" }),
  ]);
  const openOrders = settledValue(book[0], "frontendOpenOrders", errors);
  const fills = settledValue(book[1], "userFills", errors);
  const mids = settledValue(book[2], "allMids", errors);
  return {
    data: {
      openOrders: Array.isArray(openOrders) ? openOrders : [],
      fills: Array.isArray(fills) ? fills : [],
      mids: mids && typeof mids === "object" ? mids : {},
    },
    errors,
  };
}

/** Portfolio chrome — lowest priority; skip-friendly on 429. */
export async function loadAccountSlow(address) {
  const errors = [];
  await sleep(300);
  const slow = await Promise.allSettled([
    hlInfo({ type: "portfolio", user: address }),
    hlInfo({ type: "userFees", user: address }),
  ]);
  const portfolio = settledValue(slow[0], "portfolio", errors);
  const userFees = settledValue(slow[1], "userFees", errors);
  if (errors.some((e) => /429|Too Many/i.test(e))) {
    return {
      data: {
        portfolio,
        userFees: userFees && typeof userFees === "object" ? userFees : null,
        staking: null,
        delegations: null,
        subAccounts: [],
      },
      errors,
    };
  }
  await sleep(250);
  const slow2 = await Promise.allSettled([
    hlInfo({ type: "delegatorSummary", user: address }),
    hlInfo({ type: "delegations", user: address }),
    hlInfo({ type: "subAccounts", user: address }),
  ]);
  const staking = settledValue(slow2[0], "delegatorSummary", errors);
  const dels = settledValue(slow2[1], "delegations", errors);
  const subAccounts = settledValue(slow2[2], "subAccounts", errors);
  return {
    data: {
      portfolio,
      userFees: userFees && typeof userFees === "object" ? userFees : null,
      staking,
      delegations: Array.isArray(dels) ? dels : dels == null ? null : [],
      subAccounts: Array.isArray(subAccounts) ? subAccounts : [],
    },
    errors,
  };
}

/**
 * Full account load (core + book + slow). Prefer loadAccountCore + background
 * stages in UI refresh paths so balances paint in ~1–3s.
 */
export async function loadAccount(address) {
  const core = await loadAccountCore(address);
  const book = await loadAccountBook(address);
  const slow = await loadAccountSlow(address);
  return {
    data: {
      ...core.data,
      ...book.data,
      ...slow.data,
    },
    errors: [...core.errors, ...book.errors, ...slow.errors],
  };
}

function marksFromMetaCtxs(payload) {
  const out = {};
  if (!Array.isArray(payload) || !payload[0] || !Array.isArray(payload[1])) return out;
  const uni = payload[0].universe || [];
  const ctxs = payload[1];
  uni.forEach((u, i) => {
    if (!u || !u.name || !ctxs[i] || ctxs[i].markPx == null) return;
    if (Number(ctxs[i].markPx) > 0) out[u.name] = ctxs[i].markPx;
  });
  return out;
}

export async function loadMarkets() {
  const spotCtxsP = fetchSpotAssetCtxs().catch(() => ({}));
  const batch1 = await Promise.allSettled([
    hlInfo({ type: "metaAndAssetCtxs" }),
    hlInfo({ type: "spotMetaAndAssetCtxs" }),
  ]);
  await sleep(250);
  const batch2 = await Promise.allSettled([
    hlInfo({ type: "outcomeMeta" }),
    hlInfo({ type: "allMids" }),
  ]);
  await sleep(250);
  const batch3 = await Promise.allSettled([
    hlInfo({ type: "metaAndAssetCtxs", dex: "xyz" }),
    hlInfo({ type: "outcomeTemplates" }),
  ]);
  const results = [...batch1, ...batch2, ...batch3];
  const perps = results[0].status === "fulfilled" ? parsePerpMarkets(results[0].value) : [];
  const spot = results[1].status === "fulfilled" ? parseSpotMarkets(results[1].value) : [];
  const outcomeMeta = results[2].status === "fulfilled" ? results[2].value : null;
  const mids = results[3].status === "fulfilled" ? results[3].value : {};
  const hip3Marks = marksFromMetaCtxs(results[4].status === "fulfilled" ? results[4].value : null);
  const templates = results[5].status === "fulfilled" ? results[5].value : null;
  const parsed = outcomeMeta ? parseOutcomeMarkets(outcomeMeta, mids, hip3Marks, templates) : [];
  const spotCtxs = await spotCtxsP;
  const outcomes = enrichOutcomeMarkets(parsed, spotCtxs);
  const markets = mergeMarkets(perps, spot, outcomes);
  if (!markets.length) throw new Error("Hyperliquid returned no markets");
  return markets;
}

export function candleRange(interval) {
  const now = Date.now();
  const ms = {
    "1m": 60_000,
    "5m": 5 * 60_000,
    "15m": 15 * 60_000,
    "1h": 60 * 60_000,
    "4h": 4 * 60 * 60_000,
    "1d": 24 * 60 * 60_000,
  }[interval] || 60_000;
  const startTime = now - ms * 320;
  return { startTime, endTime: now };
}

/**
 * Info API candle coin. HIP-4 `+` balances become `#` wire coins.
 * TradingView slugs are refused so we never POST a 500-body to HL.
 */
export function normalizeCandleCoin(coin) {
  const s = String(coin || "").trim();
  if (!s) return "";
  if (/^out:/i.test(s) || /^HYPERLIQUID:/i.test(s)) return "";
  if (s.charAt(0) === "+" && /^\d+$/.test(s.slice(1))) return "#" + s.slice(1);
  return s;
}

export function candleSnapshotBody(coin, interval) {
  const range = candleRange(interval);
  return {
    type: "candleSnapshot",
    req: {
      coin: normalizeCandleCoin(coin),
      interval: hlCandleInterval(interval),
      startTime: range.startTime,
      endTime: range.endTime,
    },
  };
}

export function hlCandleInterval(interval) {
  return (
    {
      "1m": "1m",
      "5m": "5m",
      "15m": "15m",
      "1h": "1h",
      "4h": "4h",
      "1d": "1d",
    }[interval] || "15m"
  );
}

export async function loadCandles(coin, interval) {
  const raw = String(coin || "").trim();
  const c = normalizeCandleCoin(raw);
  if (!c) {
    if (raw) throw new Error("Invalid candle coin");
    return [];
  }
  const rows = await hlInfo(candleSnapshotBody(c, interval));
  return candlesToBars(rows);
}

export function candlesToBars(rows) {
  if (!Array.isArray(rows)) return [];
  const out = [];
  const seen = new Set();
  rows.forEach((c) => {
    const t = Math.floor(Number(c.t) / 1000);
    if (!Number.isFinite(t) || seen.has(t)) return;
    const open = Number(c.o);
    const high = Number(c.h);
    const low = Number(c.l);
    const close = Number(c.c);
    if (![open, high, low, close].every(Number.isFinite)) return;
    seen.add(t);
    out.push({ time: t, open, high, low, close, volume: Number(c.v) || 0 });
  });
  out.sort((a, b) => a.time - b.time);
  return out;
}

/** Yesterday's close from daily bars: last bar's open, else prior close. Never invents. */
export function prevDayFromDailyBars(bars) {
  if (!Array.isArray(bars) || !bars.length) return null;
  const last = bars[bars.length - 1];
  const open = Number(last && last.open);
  if (Number.isFinite(open) && open > 0) return open;
  if (bars.length >= 2) {
    const close = Number(bars[bars.length - 2].close);
    if (Number.isFinite(close) && close > 0) return close;
  }
  return null;
}

export function dailyPrevDayBody(coin) {
  const now = Date.now();
  return {
    type: "candleSnapshot",
    req: {
      coin: String(coin || ""),
      interval: "1d",
      startTime: now - 8 * 24 * 60 * 60 * 1000,
      endTime: now,
    },
  };
}

export async function loadDailyPrevDay(coin) {
  const c = String(coin || "");
  if (!c) return null;
  const rows = await hlInfo(dailyPrevDayBody(c));
  return prevDayFromDailyBars(candlesToBars(rows));
}

export async function loadTradeExtras(address) {
  // Sequential + small set — avoid stacking another 5-way burst on connect.
  // TWAP slice fills are loaded lazily via loadTwapSliceFills when the TWAP tab opens.
  const startTime = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const historicalOrders = await hlInfo({ type: "historicalOrders", user: address }).catch(() => []);
  await sleep(150);
  const fundingHistory = await hlInfo({ type: "userFunding", user: address, startTime }).catch(() => []);
  await sleep(150);
  const twapHistory = await hlInfo({ type: "twapHistory", user: address }).catch(() => []);
  return {
    historicalOrders: Array.isArray(historicalOrders) ? historicalOrders : [],
    fundingHistory: Array.isArray(fundingHistory) ? fundingHistory : [],
    twapHistory: Array.isArray(twapHistory) ? twapHistory : [],
    twapFills: [],
    userFees: null,
  };
}


/** Lazy: userTwapSliceFills — call when TWAP / Fill History is opened, not on connect. */
export async function loadTwapSliceFills(address) {
  if (!address) return [];
  const rows = await hlInfo({ type: "userTwapSliceFills", user: address }).catch(() => []);
  return Array.isArray(rows) ? rows : [];
}

export function bookLevels(snapshot) {
  const levels = snapshot && snapshot.levels;
  const bids = (levels && levels[0]) || [];
  const asks = (levels && levels[1]) || [];
  return { bids, asks, time: snapshot && snapshot.time };
}